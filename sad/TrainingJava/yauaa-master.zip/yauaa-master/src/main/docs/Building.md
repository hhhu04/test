## Building
Simply install the normal build tools for a Java project (i.e. maven and jdk 8+) and then simply do:

    mvn clean package

