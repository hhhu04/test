Related projects
===
[Stefano Balzarotti](https://github.com/OrbintSoft) is putting a lot of effort into porting Yauaa to run in .NET standard.

You can track his efforts here on Github: [Yauaa .NET standard](https://github.com/OrbintSoft/yauaa.netstandard) and
download his releases via [Nuget](https://www.nuget.org/packages/OrbintSoft.Yauaa.NetStandard).
