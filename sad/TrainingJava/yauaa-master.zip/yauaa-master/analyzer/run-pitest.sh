#!/usr/bin/env bash
mvn org.pitest:pitest-maven:mutationCoverage

